#!/bin/sh

chown -R www:www /var/lib/nginx
chown -R www:www /www
