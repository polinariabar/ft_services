influxd run -config /etc/influxdb.conf
