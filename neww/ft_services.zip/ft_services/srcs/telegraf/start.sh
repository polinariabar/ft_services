#!/bin/sh

exec /usr/bin/telegraf $@
