# **************************************************************************** #
#                                                                              #
#                                                         :::      ::::::::    #
#    setup.sh                                           :+:      :+:    :+:    #
#                                                     +:+ +:+         +:+      #
#    By: gwynton <gwynton@student.21-school.ru>     +#+  +:+       +#+         #
#                                                 +#+#+#+#+#+   +#+            #
#    Created: 2020/08/13 04:31:54 by gwynton           #+#    #+#              #
#    Updated: 2020/08/13 05:32:32 by gwynton          ###   ########.fr        #
#                                                                              #
# **************************************************************************** #

# Starting Minikube with addons
minikube start --addons metrics-server --extra-config=kubelet.authentication-token-webhook=true
minikube addons enable dashboard
minikube addons enable metallb

# Configuring metal load balancer
kubectl apply -f ./srcs/metallb.yaml

# Linking shell with Minikube context
eval $(minikube docker-env)

# Saving IP address to environment variable
export MINIKUBE_IP=$(minikube ip)

# Building FTPs
docker build -t ftps_alpine ./srcs/ftps
kubectl apply -f ./srcs/ftps.yaml

# Building MySQL
docker build -t mysql_alpine ./srcs/mysql
kubectl apply -f ./srcs/mysql.yaml

# Building WordPress
docker build -t wordpress_alpine ./srcs/wordpress
kubectl apply -f ./srcs/wordpress.yaml

# Building phpMyAdmin
docker build -t phpmyadmin_alpine ./srcs/phpmyadmin
kubectl apply -f ./srcs/phpmyadmin.yaml

# Building influxDB
docker build -t influxdb_alpine srcs/influxdb
kubectl apply -f srcs/influxdb.yaml

# Building telegraf
docker build -t telegraf_alpine --build-arg INCOMING=${MINIKUBE_IP} srcs/telegraf
kubectl apply -f srcs/telegraf.yaml

# Building grafana
docker build -t grafana_alpine ./srcs/grafana
kubectl apply -f ./srcs/grafana.yaml

# Building nginx
docker build -t nginx_alpine ./srcs/nginx
kubectl apply -f ./srcs/nginx.yaml

# Creating metalLB secret
sleep 3;
kubectl create secret generic -n metallb-system memberlist --from-literal=secretkey="$(openssl rand -base64 128)"

# Importing our good old website from May
sleep 3;
kubectl exec -i $(kubectl get pods | grep mysql | cut -d" " -f1) -- mysql wordpress -u root < srcs/wordpress/wordpress.sql
